package com.uis.coinkeeper.servicio;

import com.uis.coinkeeper.modelo.Transaccion;
import com.uis.coinkeeper.repositorio.TransaccionRepositorio;
import jakarta.transaction.Transactional;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class TransaccionService implements ITransaccionService{
    
    @Autowired
    private TransaccionRepositorio transaccionRepositorio;
    
    @Override
    public List<Transaccion> getTransacciones(){
        return transaccionRepositorio.findAll();
    }
    
    @Override
    public Transaccion buscarTransaccion(Long id){
        return transaccionRepositorio.findById(id).orElse(null);
    }
    
    @Override
    public Transaccion guardarTransaccion(Transaccion transaccion){
        return transaccionRepositorio.save(transaccion);
    }
    
    @Override
    public int borrarTransaccion(Long id){
        transaccionRepositorio.deleteById(id);
        return 1;                
    }
    
}
