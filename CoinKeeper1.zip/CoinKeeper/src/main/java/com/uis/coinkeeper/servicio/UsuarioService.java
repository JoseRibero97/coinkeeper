package com.uis.coinkeeper.servicio;

import com.uis.coinkeeper.modelo.Usuario;
import com.uis.coinkeeper.repositorio.UsuarioRepositorio;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UsuarioService implements IUsuarioService{

    @Autowired
    private UsuarioRepositorio usuarioRepositorio;
    
    @Override
    public List<Usuario> getUsuarios(){
        return usuarioRepositorio.findAll();
    }
    
    @Override
    public Usuario buscarUsuario(Long id) {
        return usuarioRepositorio.findById(id).orElse(null); // Devuelve null si no existe
    }

    public Usuario findByCorreo(String correo) {
        return usuarioRepositorio.findByCorreo(correo);
    }

    public Usuario findOrCreateByCorreoAndNombre(String correo, String nombre) {
        Usuario usuario = usuarioRepositorio.findByCorreo(correo);
        if (usuario == null) {
            usuario = new Usuario();
            usuario.setCorreo(correo);
            usuario.setNombre(nombre);
            usuario = usuarioRepositorio.save(usuario);
        }
        return usuario;
    }
    
    @Override
    public Usuario guardarUsuario(Usuario usuario) {
        return usuarioRepositorio.save(usuario);
    }
    
    @Override
    public int borrarUsuario(Long id){
        usuarioRepositorio.deleteById(id);
        return 1;
    }
        
}

