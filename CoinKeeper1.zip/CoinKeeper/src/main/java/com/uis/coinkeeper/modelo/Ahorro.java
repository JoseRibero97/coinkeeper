package com.uis.coinkeeper.modelo;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Entity
@DiscriminatorValue("Cuenta Ahorros")
public class Ahorro extends Cuenta{
    
    @NotNull
    public Double tasa;
    
    public Ahorro(){
        
    }
    
    public Ahorro(Double tasa, Usuario idUsuario, Double saldo, String nombreCuenta){
        super(idUsuario, saldo, nombreCuenta, "Cuenta Ahorros");
        this.tasa = tasa;
    
    }
    public Double getTasa(){
        return tasa;
    }
    
    public void setTasa(Double tasa){
        this.tasa = tasa;
    }
    
    public void aplicarIntereses(Cuenta cuenta){
        Double s = cuenta.getSaldo();
        s =+ s*tasa;
        cuenta.setSaldo(s);
    }
}
