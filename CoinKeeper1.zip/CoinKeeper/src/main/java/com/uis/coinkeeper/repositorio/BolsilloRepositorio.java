package com.uis.coinkeeper.repositorio;

import com.uis.coinkeeper.modelo.Bolsillo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BolsilloRepositorio extends JpaRepository<Bolsillo, Long> {
    
}
