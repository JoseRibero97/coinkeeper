package com.uis.coinkeeper.modelo;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;

@Entity
public class Usuario {
    
    @Id
    private Long id;
    
    @NotNull
    private String nombre;
    
    @NotNull
    private String correo;
    
    public Usuario(){
        
    }
    
    public Usuario(Long id, String nombre, String correo){        
        this.id = id;
        this.correo = correo;
        this.nombre = nombre;
    }
    
    public Long getId(){
        return id;
    }
    
    public void setId(Long id){
        this.id = id;
    }
    
    public String getCorreo(){
        return correo;
    }
    
    public void setCorreo(String correo){
        this.correo = correo;
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
}
