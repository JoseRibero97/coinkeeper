package com.uis.coinkeeper.modelo;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Entity
@DiscriminatorValue("Bolsillo")
public class Bolsillo extends Cuenta{
    
    @NotNull
    private Double objetivo;
    
    public Bolsillo(){
        
    }
    
    public Bolsillo(Double objetivo, Usuario idUsuario, Double saldo, String nombreCuenta){
        super(idUsuario, saldo, nombreCuenta, "Bolsillo");
        this.objetivo = objetivo;
    }
    
    public Double getObjetivo(){
        return objetivo;
    }
    
    public void setObjetivo(Double objetivo){
        this.objetivo = objetivo;
    }
}
