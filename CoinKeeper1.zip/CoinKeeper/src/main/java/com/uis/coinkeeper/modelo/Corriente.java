package com.uis.coinkeeper.modelo;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@DiscriminatorValue("Cuenta Corriente")
public class Corriente extends Cuenta{
    
    @NotNull
    private Double cupoLimite;
    
    public Corriente(){
        
    }
    
    public Corriente(Double cupoLimite, Usuario idUsuario, Double saldo, String nombreCuenta){
        super(idUsuario, saldo, nombreCuenta, "Cuenta Corriente");
        this.cupoLimite = cupoLimite;
    }
    
    public Double getCupoLimite(){
        return cupoLimite;
    }
    
    public void setCupoLimite(Double cupoLimite){
        this.cupoLimite = cupoLimite;
    }
}
