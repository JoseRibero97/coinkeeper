package com.uis.coinkeeper.modelo;

public class CuentaRequest {
    private Long idUsuario;
    private Double saldo;
    private String nombre;
    private String tipo;

    // Getters y setters
    public Long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Double getSaldo() {
        return saldo;
    }

    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }

    public String getNombreCuenta() {
        return nombre;
    }

    public void setNombreCuenta(String nombre) {
        this.nombre = nombre;
    }
    
    public String getTipo(){
        return tipo;
    }
    
    public void setTipo(String tipo){
        this.tipo = tipo;
    }
}
