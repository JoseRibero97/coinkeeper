package com.uis.coinkeeper.servicio;

import com.uis.coinkeeper.modelo.Usuario;
import java.util.List;


public interface IUsuarioService {
    List<Usuario> getUsuarios();
    
    Usuario buscarUsuario(Long id);
    
    Usuario guardarUsuario(Usuario usuario);
    
    int borrarUsuario(Long id);
}
