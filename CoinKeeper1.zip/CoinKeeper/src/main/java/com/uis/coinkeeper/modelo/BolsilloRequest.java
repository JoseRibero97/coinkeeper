package com.uis.coinkeeper.modelo;

public class BolsilloRequest {
    private Double objetivo;
    private Long idUsuario;
    private Double saldo;
    private String nombreCuenta;

    // Getters y setters
    public Long getIdUsuario() {
        return idUsuario;
    }
    
    public Double getObjetivo(){
        return objetivo;
    }
    
    public void setObjetivo(Double objetivo){
        this.objetivo = objetivo;
    }
    
    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Double getSaldo() {
        return saldo;
    }

    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }

    public String getNombreCuenta() {
        return nombreCuenta;
    }

    public void setNombreCuenta(String nombreCuenta) {
        this.nombreCuenta = nombreCuenta;
    }
}
