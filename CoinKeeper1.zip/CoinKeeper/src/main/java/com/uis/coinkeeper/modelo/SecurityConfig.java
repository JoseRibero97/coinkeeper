package com.uis.coinkeeper.modelo;

//EnableMethodSecurity
//Configuration
public class SecurityConfig {

    
}
