package com.uis.coinkeeper.controlador;

import com.uis.coinkeeper.modelo.Ahorro;
import com.uis.coinkeeper.modelo.AhorroRequest;
import com.uis.coinkeeper.modelo.Bolsillo;
import com.uis.coinkeeper.modelo.BolsilloRequest;
import com.uis.coinkeeper.modelo.Corriente;
import com.uis.coinkeeper.modelo.CorrienteRequest;
import com.uis.coinkeeper.modelo.Cuenta;
import com.uis.coinkeeper.modelo.CuentaRequest;
import com.uis.coinkeeper.modelo.Usuario;
import com.uis.coinkeeper.servicio.CuentaService;
import com.uis.coinkeeper.servicio.UsuarioService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@CrossOrigin
@RestController
@RequestMapping("/api/cuenta")
public class CuentaControlador {
    @Autowired
    private CuentaService cuentaService;
    
    @Autowired
    private UsuarioService usuarioService;
    
    @CrossOrigin
    @GetMapping("/list")
    public List<Cuenta> mostrarCuentas(){
        return cuentaService.getCuentas();
    }
    
    @CrossOrigin
    @GetMapping("/{id}")
    public Cuenta buscarCuentaId(@PathVariable Long id){
        return cuentaService.buscarCuenta(id);
    }
    
    @CrossOrigin
    @PostMapping("/")
    public ResponseEntity<Cuenta> agregar(@RequestBody Cuenta cuenta){
        return new ResponseEntity<>(cuentaService.guardarCuenta(cuenta) , HttpStatus.OK);
    }
    
    @CrossOrigin
    @PostMapping("/ahorro/{id}")
    public ResponseEntity<Ahorro> crearAhorro(@PathVariable Long id, @RequestBody AhorroRequest request){
        Usuario usuarioExistente = usuarioService.buscarUsuario(id);
        if (usuarioExistente == null){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        Ahorro cuenta = new Ahorro();       
        cuenta.setSaldo(request.getSaldo());
        cuenta.setNombreCuenta(request.getNombreCuenta());
        cuenta.setTasa(request.getTasa());
        cuenta.setUsuario(usuarioExistente);
        
        return new ResponseEntity<>(cuentaService.guardarAhorro(cuenta) , HttpStatus.OK);
    }
    
    @CrossOrigin
    @PostMapping("/corriente")
    public ResponseEntity<Corriente> crearCorriente(@RequestBody CorrienteRequest request){
        Usuario usuarioExistente = usuarioService.buscarUsuario(request.getIdUsuario());
        if (usuarioExistente == null){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        Corriente cuenta = new Corriente();       
        cuenta.setSaldo(request.getSaldo());
        cuenta.setNombreCuenta(request.getNombreCuenta());
        cuenta.setCupoLimite(request.getCupoLimite());
        cuenta.setUsuario(usuarioExistente);
        
        return new ResponseEntity<>(cuentaService.guardarCorriente(cuenta) , HttpStatus.OK);
    }
    
    @CrossOrigin
    @PostMapping("/bolsillo")
    public ResponseEntity<Bolsillo> crearBolsillo(@RequestBody BolsilloRequest request){
        Usuario usuarioExistente = usuarioService.buscarUsuario(request.getIdUsuario());
        if (usuarioExistente == null){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        Bolsillo cuenta = new Bolsillo();
        cuenta.setSaldo(request.getSaldo());
        cuenta.setNombreCuenta(request.getNombreCuenta());
        cuenta.setObjetivo(request.getObjetivo());
        cuenta.setUsuario(usuarioExistente);
        
        return new ResponseEntity<>(cuentaService.guardarBolsillo(cuenta) , HttpStatus.OK);
    }    
    
    @CrossOrigin
    @PutMapping("/{id}")
    public ResponseEntity<Cuenta> actualizarCuenta(@PathVariable Long id, @RequestBody CuentaRequest cuentaRequest) {
        Cuenta cuentaExistente = cuentaService.buscarCuenta(id);
        if (cuentaExistente == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        Usuario usuario = usuarioService.buscarUsuario(cuentaRequest.getIdUsuario());
        if (usuario == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        cuentaExistente.setUsuario(usuario);
        cuentaExistente.setSaldo(cuentaRequest.getSaldo());
        cuentaExistente.setTipo(cuentaRequest.getTipo());
        cuentaExistente.setNombreCuenta(cuentaRequest.getNombreCuenta());

        Cuenta cuentaActualizada = cuentaService.guardarCuenta(cuentaExistente);

        return new ResponseEntity<>(cuentaActualizada, HttpStatus.OK);
    }
    
    @CrossOrigin
    @PutMapping("/ahorro")
    public ResponseEntity<Ahorro> editarAhorro(@RequestBody Ahorro ahorro){
        Ahorro obj = cuentaService.buscarAhorro(ahorro.getId());
        if(obj != null){
            obj.setNombreCuenta(ahorro.getNombreCuenta());
            obj.setSaldo(ahorro.getSaldo());
            obj.setUsuario(ahorro.getUsuario());
            obj.setTasa(ahorro.getTasa());
            obj.setFechaInicio(ahorro.getFechaInicio());
            cuentaService.guardarCuenta(obj);
            return new ResponseEntity<>(obj, HttpStatus.OK);
        }else{
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @CrossOrigin
    @PutMapping("/corriente")
    public ResponseEntity<Corriente> editarCorriente(@RequestBody Corriente corriente){
        Corriente obj = cuentaService.buscarCorriente(corriente.getId());
        if(obj != null){
            obj.setCupoLimite(corriente.getCupoLimite());
            obj.setNombreCuenta(corriente.getNombreCuenta());
            obj.setSaldo(corriente.getSaldo());
            obj.setUsuario(corriente.getUsuario());
            obj.setFechaInicio(corriente.getFechaInicio());
            cuentaService.guardarCuenta(obj);
            return new ResponseEntity<>(obj, HttpStatus.OK);
        }else{
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @CrossOrigin
    @PutMapping("/bolsillo")
    public ResponseEntity<Bolsillo> editarBolsillo(@RequestBody Bolsillo bolsillo){
        Bolsillo obj = cuentaService.buscarBolsillo(bolsillo.getId());
        if(obj != null){
            obj.setObjetivo(bolsillo.getObjetivo());
            obj.setNombreCuenta(bolsillo.getNombreCuenta());
            obj.setSaldo(bolsillo.getSaldo());
            obj.setUsuario(bolsillo.getUsuario());
            obj.setFechaInicio(bolsillo.getFechaInicio());
            cuentaService.guardarCuenta(obj);
            return new ResponseEntity<>(obj, HttpStatus.OK);
        }else{
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
        
    @CrossOrigin
    @DeleteMapping("/{id}")
    public ResponseEntity<Cuenta> borrar(@PathVariable Long id){
        Cuenta obj = cuentaService.buscarCuenta(id);
        if(obj != null){
            cuentaService.borrarCuenta(id);
            return new ResponseEntity<>(obj, HttpStatus.OK);
        }else{
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }    
}
