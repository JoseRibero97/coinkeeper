package com.uis.coinkeeper.servicio;

import com.uis.coinkeeper.modelo.Transaccion;
import java.util.List;

public interface ITransaccionService {
    List<Transaccion> getTransacciones();
    
    Transaccion guardarTransaccion(Transaccion transaccion);
    
    Transaccion buscarTransaccion(Long id);
    
    int borrarTransaccion(Long id);
}
