package com.uis.coinkeeper.modelo;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Cuenta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "idUsuario")
    private Usuario idUsuario;    
    
    @Column(name="saldo")
    @NotNull
    private Double saldo;
    
    @Column(name="tipo")
    @NotNull
    private String tipo;
    
    @Column(name="nombreCuenta")
    @NotNull
    private String nombreCuenta;
    
    @Column(name="fechaInicio")
    private LocalDateTime fechaInicio;
    
    public Cuenta() {
        
    }
    
    public Cuenta(Usuario idUsuario, Double saldo, String nombreCuenta, String tipo) {
        this.idUsuario = idUsuario;
        this.saldo = saldo;
        this.fechaInicio = LocalDateTime.now();
        this.nombreCuenta = nombreCuenta;
        this.tipo = tipo;
    }
    
    public Long getId(){
        return id;
    }
    
    public void setId(Long id){
        this.id = id;
    }
    
    public String getTipo(){
        return tipo;
    }
    
    public void setTipo(String tipo){
        this.tipo = tipo;
    }
    
    public Usuario getUsuario(){
        return idUsuario;
    }
    
    public void setUsuario(Usuario idUsuario){
        this.idUsuario = idUsuario;
    }
    
    public Double getSaldo(){
        return saldo;
    }
    
    public void setSaldo(Double saldo){
        this.saldo = saldo;
    }
    
    public LocalDateTime getFechaInicio(){
        return fechaInicio;
    }
    
    public void setFechaInicio(LocalDateTime fechaInicio){
        this.fechaInicio = fechaInicio;
    }
    
    public String getNombreCuenta(){
        return nombreCuenta;
    }
    
    public void setNombreCuenta(String nombreCuenta){
        this.nombreCuenta = nombreCuenta;
    }
}
