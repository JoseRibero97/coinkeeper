package com.uis.coinkeeper.repositorio;

import com.uis.coinkeeper.modelo.Ahorro;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AhorroRepositorio extends JpaRepository<Ahorro, Long> {
            
}
