package com.uis.coinkeeper.modelo;

public class AhorroRequest {
    private Double tasa;
    private Long idUsuario;
    private Double saldo;
    private String nombreCuenta;

    // Getters y setters
    public Long getIdUsuario() {
        return idUsuario;
    }
    
    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }
    
    public Double getTasa(){
        return tasa;
    }
    
    public void setTasa(Double tasa){
        this.tasa = tasa;
    }

    public Double getSaldo() {
        return saldo;
    }

    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }

    public String getNombreCuenta() {
        return nombreCuenta;
    }

    public void setNombreCuenta(String nombreCuenta) {
        this.nombreCuenta = nombreCuenta;
    }
}
