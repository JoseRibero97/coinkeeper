package com.uis.coinkeeper.controlador;

import com.uis.coinkeeper.modelo.Cuenta;
import com.uis.coinkeeper.modelo.Transaccion;
import com.uis.coinkeeper.modelo.TransaccionRequest;
import com.uis.coinkeeper.servicio.CuentaService;
import com.uis.coinkeeper.servicio.TransaccionService;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/api/transaccion")
public class TransaccionControlador {
    
    @Autowired
    private TransaccionService transaccionService;
    
    @Autowired
    private CuentaService cuentaService;
    
    @CrossOrigin
    @GetMapping("/list")
    public List<Transaccion> buscarTransacciones(){
        return transaccionService.getTransacciones();
    }
    
    @CrossOrigin
    @GetMapping("/{id}")
    public Transaccion buscarTransaccionPorId(@PathVariable Long id){
        return transaccionService.buscarTransaccion(id);
    }
    
    @CrossOrigin
    @PostMapping("/")
    public ResponseEntity<Transaccion> crearTransaccion(@RequestBody TransaccionRequest request){
        Long idcuenta = request.getIdCuenta();
        Double monto = request.getMonto();
        String descripcion = request.getDescripcion();
        
        Cuenta cuenta = cuentaService.buscarCuenta(idcuenta);
        if (cuenta != null){
            cuenta.setSaldo(cuenta.getSaldo()+monto);
            cuentaService.guardarCuenta(cuenta);
            
            Transaccion transaccion = new Transaccion(cuenta,monto,descripcion);
            transaccion.setFecha(LocalDateTime.now());
            
            Transaccion t = transaccionService.guardarTransaccion(transaccion);
            return new ResponseEntity<>(t, HttpStatus.OK);
        }else{
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
    }
}
