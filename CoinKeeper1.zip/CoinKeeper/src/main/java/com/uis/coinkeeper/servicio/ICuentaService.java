package com.uis.coinkeeper.servicio;

import com.uis.coinkeeper.modelo.Ahorro;
import com.uis.coinkeeper.modelo.Bolsillo;
import com.uis.coinkeeper.modelo.Corriente;
import com.uis.coinkeeper.modelo.Cuenta;
import java.util.List;

public interface ICuentaService {
    List<Cuenta> getCuentas();
    
    Cuenta guardarCuenta(Cuenta cuenta);
    
    Cuenta buscarCuenta(Long id);
    
    Ahorro buscarAhorro(Long id);
    
    Corriente buscarCorriente(Long id);
    
    Bolsillo buscarBolsillo(Long id);
    
    int borrarCuenta(Long id);
}
