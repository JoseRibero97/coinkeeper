package com.uis.coinkeeper.servicio;

import com.uis.coinkeeper.modelo.Ahorro;
import com.uis.coinkeeper.modelo.Bolsillo;
import com.uis.coinkeeper.modelo.Corriente;
import com.uis.coinkeeper.modelo.Cuenta;
import com.uis.coinkeeper.repositorio.AhorroRepositorio;
import com.uis.coinkeeper.repositorio.BolsilloRepositorio;
import com.uis.coinkeeper.repositorio.CorrienteRepositorio;
import com.uis.coinkeeper.repositorio.CuentaRepositorio;
import jakarta.transaction.Transactional;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class CuentaService implements ICuentaService{
    
    @Autowired
    private CuentaRepositorio cuentaRepositorio;
    private AhorroRepositorio ahorroRepositorio;
    private CorrienteRepositorio corrienteRepositorio;    
    private BolsilloRepositorio bolsilloRepositorio;

    @Override
    public List<Cuenta> getCuentas() {
        return cuentaRepositorio.findAll();
    }

    @Override
    public Cuenta guardarCuenta(Cuenta cuenta) {
        return cuentaRepositorio.save(cuenta);
    }
    
    public Ahorro guardarAhorro(Ahorro ahorro){
        return ahorroRepositorio.save(ahorro);
    }
    
    public Corriente guardarCorriente(Corriente corriente){
        return corrienteRepositorio.save(corriente);
    }
    
    public Bolsillo guardarBolsillo(Bolsillo bolsillo){
        return bolsilloRepositorio.save(bolsillo);
    }
    
    @Override
    public Cuenta buscarCuenta(Long id) {
        return cuentaRepositorio.findById(id).orElse(null);
    }
    
    @Override
    public Ahorro buscarAhorro(Long id) {
        return ahorroRepositorio.findById(id).orElse(null);
    }
    
    @Override
    public Corriente buscarCorriente(Long id) {
        return corrienteRepositorio.findById(id).orElse(null);
    }
    
    @Override
    public Bolsillo buscarBolsillo(Long id) {
        return bolsilloRepositorio.findById(id).orElse(null);
    }
    
    @Override
    public int borrarCuenta(Long id) {
        cuentaRepositorio.deleteById(id);
        return 1;
    }
    
}
