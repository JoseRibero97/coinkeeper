package com.uis.coinkeeper.repositorio;

import com.uis.coinkeeper.modelo.Cuenta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CuentaRepositorio extends JpaRepository<Cuenta, Long> {
               
}
