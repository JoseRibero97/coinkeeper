package com.uis.coinkeeper.modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
public class Transaccion {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "idCuenta")
    private Cuenta idCuenta;
    
    @Column(name="monto")
    @NotNull
    private Double monto;
    
    @Column(name="descripcion")
    @NotNull
    private String descripcion;
    
    @Column(name="fecha")
    private LocalDateTime fecha;
    
    public Transaccion(){
        this.fecha = LocalDateTime.now();
    }
    
    public Transaccion(Cuenta idCuenta, Double monto, String descripcion){        
        this.idCuenta = idCuenta;
        this.monto = monto;
        this.descripcion = descripcion;
        this.fecha = LocalDateTime.now();
    }
    
    public Long getId(){
        return id;
    }
    
    public void setId(Long id){
        this.id = id; 
    }
    
    public Cuenta getIdCuenta(){
        return idCuenta;
    }
    
    public void setIdCuenta(Cuenta idCuenta){
        this.idCuenta = idCuenta;
    }
    
    public Double getMonto(){
        return monto;
    }
    
    public void setMonto(Double monto){
        this.monto = monto;
    }
    
    public LocalDateTime getFecha(){
        return fecha;
    }
    
    public void setFecha(LocalDateTime fecha){
        this.fecha = fecha;
    }
    
    public String getDescripcion(){
        return descripcion;                
    }    
}
