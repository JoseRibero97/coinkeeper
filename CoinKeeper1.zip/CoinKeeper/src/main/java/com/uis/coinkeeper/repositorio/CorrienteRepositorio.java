package com.uis.coinkeeper.repositorio;

import com.uis.coinkeeper.modelo.Corriente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CorrienteRepositorio extends JpaRepository<Corriente, Long> {
    
}
