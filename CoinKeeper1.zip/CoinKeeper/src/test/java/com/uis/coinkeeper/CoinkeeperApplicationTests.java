package com.uis.coinkeeper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoinkeeperApplicationTests {

	@Test
	void contextLoads() {
	}

}
